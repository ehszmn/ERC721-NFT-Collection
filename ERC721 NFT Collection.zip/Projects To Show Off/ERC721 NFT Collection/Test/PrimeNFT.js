const { expect } = require("chai");
const { ethers } = require("hardhat");
const { buildTree } = require("./helpers/merkle");

describe("PrimeNFT (JS tests)", function () {
  const MAX_SUPPLY = 3333n;
  const PRICE_PRESALE = ethers.parseEther("0.05");
  const PRICE_PUBLIC  = ethers.parseEther("0.08");
  const MAX_PER_TX = 5n;
  const MAX_PER_WALLET = 10n;

  async function deploy() {
    const [owner, w1, w2, w3, p0, p1, p2] = await ethers.getSigners();

    const PrimeNFT = await ethers.getContractFactory("PrimeNFT");
    const nft = await PrimeNFT.deploy(
      "PrimeNFT",
      "PNFT",
      MAX_SUPPLY,
      PRICE_PRESALE,
      PRICE_PUBLIC,
      MAX_PER_TX,
      MAX_PER_WALLET,
      owner.address, // royalties receiver
      500,           // 5%
      [p0.address, p1.address, p2.address],
      [70, 20, 10]
    );
    await nft.waitForDeployment();

    return { nft, owner, w1, w2, w3, p0, p1, p2 };
  }

  it("public mint + limits + wrong value", async () => {
    const { nft, w1, w2, owner } = await deploy();

    await nft.connect(owner).setSaleState(false, true, PRICE_PRESALE, PRICE_PUBLIC);

    // mint 3
    await expect(nft.connect(w1).mintPublic(3, { value: PRICE_PUBLIC * 3n }))
      .to.emit(nft, "Transfer").withArgs(ethers.ZeroAddress, w1.address, 1);

    expect(await nft.totalSupply()).to.equal(3n);
    expect(await nft.balanceOf(w1.address)).to.equal(3n);

    // per-tx
    await expect(nft.connect(w1).mintPublic(MAX_PER_TX + 1n, { value: PRICE_PUBLIC * (MAX_PER_TX + 1n) }))
      .to.be.revertedWithCustomError(nft, "ExceedsTxLimit");

    // per-wallet
    await nft.connect(w1).mintPublic(5, { value: PRICE_PUBLIC * 5n }); // now 8
    await expect(nft.connect(w1).mintPublic(3, { value: PRICE_PUBLIC * 3n }))
      .to.be.revertedWithCustomError(nft, "ExceedsWalletLimit");

    // wrong ether
    await expect(nft.connect(w2).mintPublic(1, { value: 1n }))
      .to.be.revertedWithCustomError(nft, "WrongEtherValue");
  });

  it("pause blocks mint & transfer", async () => {
    const { nft, owner, w1, w2 } = await deploy();
    await nft.connect(owner).setSaleState(false, true, PRICE_PRESALE, PRICE_PUBLIC);
    await nft.connect(w1).mintPublic(1, { value: PRICE_PUBLIC });

    await nft.connect(owner).pause();

    await expect(nft.connect(w2).mintPublic(1, { value: PRICE_PUBLIC }))
      .to.be.revertedWith("Pausable: paused");

    await expect(nft.connect(w1).transferFrom(w1.address, w2.address, 1))
      .to.be.revertedWith("Pausable: paused");
  });

  it("presale with Merkle proof", async () => {
    const { nft, owner, w1, w2, w3 } = await deploy();

    const { root, proofFor } = buildTree([w1.address, w2.address]); // w1, w2 whitelisted
    await nft.connect(owner).setMerkleRoot(root);
    await nft.connect(owner).setSaleState(true, false, PRICE_PRESALE, PRICE_PUBLIC);

    await nft.connect(w1).mintPresale(2, proofFor(w1.address), { value: PRICE_PRESALE * 2n });
    expect(await nft.balanceOf(w1.address)).to.equal(2n);

    await expect(nft.connect(w3).mintPresale(1, [], { value: PRICE_PRESALE }))
      .to.be.revertedWithCustomError(nft, "NotWhitelisted");
  });

  it("reveal + freeze metadata", async () => {
    const { nft, owner } = await deploy();

    await nft.connect(owner).setHiddenURI("ipfs://hidden.json");
    await nft.connect(owner).setBaseURI("ipfs://meta/");
    await nft.connect(owner).setRevealed(true);

    await expect(nft.connect(owner).freezeMetadata())
      .to.emit(nft, "MetadataFrozen");

    await expect(nft.connect(owner).freezeMetadata())
      .to.be.revertedWithCustomError(nft, "AlreadySet");

    await expect(nft.connect(owner).setBaseURI("ipfs://new/"))
      .to.be.revertedWithCustomError(nft, "ErrMetadataFrozen");
  });

  it("royalties EIP-2981", async () => {
    const { nft, owner } = await deploy();
    const [, amount] = await nft.royaltyInfo(1, ethers.parseEther("1"));
    expect(amount).to.equal(ethers.parseEther("0.05"));
    // supportsInterface(0x2a55205a)
    expect(await nft.supportsInterface("0x2a55205a")).to.equal(true);
  });

  it("provenance + startingIndex", async () => {
    const { nft, owner } = await deploy();
    const prov = ethers.keccak256(ethers.toUtf8Bytes("MY_PROVENANCE_HASH"));

    await nft.connect(owner).commitProvenance(prov);

    // چند بلاک جلو برویم تا blockhash قابل دسترس باشد
    await ethers.provider.send("hardhat_mine", ["0x10"]); // 16 blocks

    await expect(nft.connect(owner).finalizeStartingIndex())
      .to.emit(nft, "StartingIndexSet");

    const si = await nft.startingIndex();
    expect(si).to.be.greaterThan(0n);
    expect(si).to.be.at.most(MAX_SUPPLY);

    await expect(nft.connect(owner).finalizeStartingIndex())
      .to.be.revertedWithCustomError(nft, "AlreadySet");
  });

  it("payment splitter releaseAll", async () => {
    const { nft, owner, w1, w2, p0, p1, p2 } = await deploy();
    await nft.connect(owner).setSaleState(false, true, PRICE_PRESALE, PRICE_PUBLIC);
    await nft.connect(w1).mintPublic(4, { value: PRICE_PUBLIC * 4n });
    await nft.connect(w2).mintPublic(1, { value: PRICE_PUBLIC * 1n });

    const b0 = await ethers.provider.getBalance(p0.address);
    const b1 = await ethers.provider.getBalance(p1.address);
    const b2 = await ethers.provider.getBalance(p2.address);

    await nft.connect(owner).releaseAll();

    expect(await ethers.provider.getBalance(p0.address)).to.be.gt(b0);
    expect(await ethers.provider.getBalance(p1.address)).to.be.gt(b1);
    expect(await ethers.provider.getBalance(p2.address)).to.be.gt(b2);
  });

  it("burn updates totalSupply", async () => {
    const { nft, owner, w1 } = await deploy();
    await nft.connect(owner).setSaleState(false, true, PRICE_PRESALE, PRICE_PUBLIC);
    await nft.connect(w1).mintPublic(2, { value: PRICE_PUBLIC * 2n });
    expect(await nft.totalSupply()).to.equal(2n);
    await nft.connect(w1).burn(1);
    expect(await nft.totalSupply()).to.equal(1n);
  });
});
