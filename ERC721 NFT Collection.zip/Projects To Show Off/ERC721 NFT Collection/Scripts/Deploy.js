const hre = require("hardhat");
const { buildTree } = require("../test/helpers/merkle"); // همون هلسپر مرکل که قبل نوشتیم

async function main() {
  const [deployer, wl1, wl2] = await hre.ethers.getSigners();

  console.log("Deploying with:", deployer.address);

  const PrimeNFT = await hre.ethers.getContractFactory("PrimeNFT");

  const nft = await PrimeNFT.deploy(
    "PrimeNFT",
    "PNFT",
    3333,
    hre.ethers.parseEther("0.05"),
    hre.ethers.parseEther("0.08"),
    5,
    10,
    deployer.address,
    500, // 5%
    [deployer.address],
    [100]
  );
  await nft.waitForDeployment();

  console.log("PrimeNFT deployed at:", await nft.getAddress());

  // === تنظیمات اولیه ===
  const hiddenURI = "ipfs://hidden.json";
  await (await nft.setHiddenURI(hiddenURI)).wait();
  console.log("Hidden URI set:", hiddenURI);

  // Whitelist (مثال: wl1 و wl2 whitelisted)
  const { root } = buildTree([wl1.address, wl2.address]);
  await (await nft.setMerkleRoot(root)).wait();
  console.log("Merkle root set:", root);

  // فعال‌سازی presale
  await (await nft.setSaleState(true, false, hre.ethers.parseEther("0.05"), hre.ethers.parseEther("0.08"))).wait();
  console.log("Presale active.");
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
