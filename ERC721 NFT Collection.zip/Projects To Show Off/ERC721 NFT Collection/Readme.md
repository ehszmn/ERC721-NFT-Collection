# 🖼️ PrimeNFT --- ERC721 Collection

An advanced **ERC721 NFT collection** built in Solidity with full
support for Presale, Public Sale, Reveal, Provenance, Royalties, and
Payment Splitter.\
Powered by **Hardhat + OpenZeppelin 4.9.5**.

------------------------------------------------------------------------

## ✨ Features

-   ✅ Presale with Merkle Tree whitelist + Public Sale\
-   ✅ Per-transaction and per-wallet mint limits\
-   ✅ Reveal/Hidden Metadata + Freeze Metadata\
-   ✅ Provenance Hash + Randomized Starting Index for fairness\
-   ✅ EIP-2981 Royalties (configurable)\
-   ✅ Pausable + ReentrancyGuard\
-   ✅ PaymentSplitter for revenue sharing\
-   ✅ Full test coverage with Hardhat/Mocha/Chai

------------------------------------------------------------------------

## 📦 Installation

``` bash
git clone https://github.com/YOUR_GITHUB/prime-nft-hardhat.git
cd prime-nft-hardhat
npm install
```

### Requirements

-   [Node.js](https://nodejs.org/) ≥ 18
-   [Hardhat](https://hardhat.org/)\
-   An RPC provider (Infura, Alchemy, etc.)

------------------------------------------------------------------------

## ⚙️ Environment Setup

Create a `.env` file in the project root:

``` ini
SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/YOUR_KEY
MAINNET_RPC_URL=https://mainnet.infura.io/v3/YOUR_KEY
PRIVATE_KEY=0xyourprivatekey
```

------------------------------------------------------------------------

## 🛠️ Commands

### Compile

``` bash
npm run compile
```

### Run tests

``` bash
npm run test
```

### Deploy to local Hardhat node

``` bash
npm run deploy:local
```

### Deploy to Sepolia

``` bash
npm run deploy:sepolia
```

### Deploy to Mainnet

``` bash
npm run deploy:mainnet
```

------------------------------------------------------------------------

## 📜 Scripts

-   `scripts/deploy.js` → Basic deployment script\
-   `scripts/deploy_full.js` → Deployment with initial setup (presale,
    hiddenURI, merkle root)

------------------------------------------------------------------------

## 🧪 Tests

Located under `test/` using Mocha/Chai.\
Covers: - Public mint + limits\
- Presale + Merkle Proof\
- Pause/Unpause\
- Reveal & Freeze Metadata\
- Provenance & StartingIndex\
- Royalties\
- Payment Splitter\
- Burn + totalSupply

------------------------------------------------------------------------

## 🌐 Contract

-   Standard: ERC721 + ERC2981\
-   Solidity: \^0.8.24\
-   OpenZeppelin: 4.9.5

------------------------------------------------------------------------

## 📂 Project Structure

    prime-nft-hardhat/
    ├── contracts/
    │   └── PrimeNFT.sol
    ├── scripts/
    │   ├── deploy.js
    ├── test/
    │   ├── PrimeNFT.js
    ├── hardhat.config.js
    ├── package.json
    └── README.md

------------------------------------------------------------------------

## 👨‍💻 Author

Developed by **Ehsan**
Designed to be professional, production-ready, and resume/GitHub
showcase friendly.
